// Copyright (c) 2018 Lean Web Solutions https://leanws.com

var IDget=function(id){return document.getElementById(id)};
var load,loads,onLoad=[];
window.onload=function(){onLoad.forEach(function(f){f()})}
function whenReady(IDs,f){
if(IDs.map(x=>Boolean(IDget(x))).reduce((x,y)=>x&&y)){f()}
else{onLoad.push(f)}}
var capability={"to":(function(){
"use strict";
if(typeof Symbol=="undefined") return false;
try{eval("var bar=(x)=> x+1");
}catch(e){return false}
return true})()};
if(!capability["to"]){
var el=IDget("message");
el.innerHTML='Please use a newer browser for this website.';
el.style.display='inline'}else{
load=(function(){
var loadedFiles={};
return function(oneFile){
if(oneFile in loadedFiles){return loadedFiles[oneFile]}
else{
return (loadedFiles[oneFile]=new Promise(function(resolve,reject){
if(oneFile.endsWith('.js')){
var tag=document.createElement('script');
tag.src='https://t.leanws.com/'+oneFile;tag.async=true;
tag.onload=function(){return resolve(oneFile)};tag.onerror=function(){return reject(oneFile)};
var bl=document.getElementsByTagName('script')[0];
bl.parentNode.insertBefore(tag,bl)}
else if(oneFile.endsWith('.css')){
var tag=document.createElement('link');
tag.type='text/css';tag.rel='stylesheet';tag.href=oneFile;
tag.onload=function(){return resolve(oneFile)};
document.head.appendChild(tag)}
else{
load("/js-lib/ajaxme.js").then(
()=>window.AjaxMe.get({url:oneFile,
success:r=>{
resolve(r.response)},
error:r=>reject(r)}))}}))}}})();
loads=function(by){
return Promise.all(by.map(x=>load(x)))};
loads(["2.js","/js-lib/js.cookie.js","js-lib/ajaxme.js"]);
if(typeof localScripts!="undefined")loads(localScripts)
}
