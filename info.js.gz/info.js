// Copyright (c) 2018 Lean Web Solutions https://leanws.com

const infoContainer=document.querySelectorAll("div.fon")[0];
loads(['info.json','2.js']).then(function(prs){
const info=JSON.parse(prs[0]),topic=getURLParameter("t");
if(topic){
document.title+=':'+info[topic]["header"];
html("infoTopic",info[topic]["header"]);
load(info[topic].content).then(function(chat){
var p1=/<section[^>]*>/,remainingText=chat,sections=[];
while(p1.test(remainingText)){
var sectionHeader=p1.exec(remainingText)[0],title="",
sectionStartsAt=remainingText.indexOf(sectionHeader),
endOfHeader=1+sectionStartsAt+sectionHeader.length;
if(titleSS=/title="[A-Za-z0-9 ]+"/.exec(sectionHeader)){
title=titleSS[0].substring('title="'.length,titleSS[0].length-1)}
end=remainingText.indexOf("</section>");
sections.push({"text":remainingText.substring(endOfHeader,end), "title":title});
remainingText=remainingText.substring(end+"</section>".length,remainingText.length)}
sections.forEach(function(s){
var tag=document.createElement('article');
tag.classList="story center";
if(s.title!=""){
var tt=document.createElement('h2');
tt.textContent=s.title;
tag.appendChild(tt)}
s.text.split("\n\n").forEach(function(tc){
var p=document.createElement('p');
p.innerHTML=tc;
tag.appendChild(p)});
infoContainer.appendChild(tag);
})})}});
